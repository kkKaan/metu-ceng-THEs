import PE2

paths8 = findViablePaths 5 (Leaf Cavern [Fight (Enemy "Skeleton" 10 15), Treasure (Potion 10)])

ans8 = EmptyTree

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(paths8, ans8)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (paths8, ans8))
