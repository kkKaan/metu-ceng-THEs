import PE2

dungeon = 
    Node Cavern [Fight (Enemy "Goblins" 5 2)] [
        Node NarrowPassage [Fight (Enemy "Skeleton" 10 15)] [
            Node NarrowPassage [Treasure (Gold 2)] [
                Node UndergroundRiver [Fight (Enemy "Necromancer" 30 100)] [
                    Leaf SlipperyRocks [Fight (Enemy "Skeleton" 10 15)]]]],
        Node SlipperyRocks [Fight (Enemy "Skeleton" 10 15)] [
            Node UndergroundRiver [Fight (Enemy "Goblins" 5 2), Fight (Enemy "Goblins" 5 2)] [
                Leaf NarrowPassage [Fight (Enemy "Lich" 25 50)],
                Leaf Cavern [Fight (Enemy "Goblins" 5 2)],
                Leaf NarrowPassage [Fight (Enemy "Zombie" 15 10)]]],
        Node NarrowPassage [Fight (Enemy "Bandit" 7 5)] [
            Node UndergroundRiver [Fight (Enemy "Rat" 2 1)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Zombie" 15 10)],
                    Leaf Cavern [Fight (Enemy "Skeleton" 10 15)],
                    Leaf UndergroundRiver [Fight (Enemy "Fighter" 40 100)]]]]]

st7 = mostEfficientSubtree dungeon

ans7 =
    Node NarrowPassage [Treasure (Gold 2)] [
        Node UndergroundRiver [Fight (Enemy "Necromancer" 30 100)] [
            Leaf SlipperyRocks [Fight (Enemy "Skeleton" 10 15)]]]

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(st7, ans7)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (st7, ans7))
