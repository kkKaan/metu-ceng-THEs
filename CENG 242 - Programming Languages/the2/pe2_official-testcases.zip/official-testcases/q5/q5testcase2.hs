import PE2

dungeonMap2 = Leaf Cavern [Fight (Enemy "Zombie" 5 10)]

st2 = mostEfficientSubtree dungeonMap2

ans2 = Leaf Cavern [Fight (Enemy "Zombie" 5 10)]

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(st2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (st2, ans2))
