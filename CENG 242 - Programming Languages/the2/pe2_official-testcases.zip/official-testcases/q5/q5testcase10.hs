import PE2

dungeon = 
    Node Cavern [Fight (Enemy "Paladin" 50 350)] [
        Node NarrowPassage [Fight (Enemy "Skeleton" 10 15)] [
            Node NarrowPassage [Treasure (Gold 2)] [
                Node UndergroundRiver [Fight (Enemy "Necromancer" 30 100)] [
                    Leaf SlipperyRocks [Fight (Enemy "Skeleton" 10 15)]]]],
        Node SlipperyRocks [Fight (Enemy "Skeleton" 10 15)] [
            Node UndergroundRiver [Fight (Enemy "Goblins" 5 2), Fight (Enemy "Goblins" 5 2)] [
                Leaf NarrowPassage [Fight (Enemy "Lich" 25 50)],
                Leaf Cavern [Fight (Enemy "Goblins" 5 2)],
                Leaf NarrowPassage [Fight (Enemy "Zombie" 15 10)]]],
        Node NarrowPassage [Fight (Enemy "Alchemist" 10 40)] [
            Node UndergroundRiver [Fight (Enemy "Lion" 8 25)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Zombie" 15 10)],
                    Leaf Cavern [Fight (Enemy "Skeleton" 10 15)],
                    Leaf UndergroundRiver [Fight (Enemy "Fighter" 40 100)]]]]]

st10 = mostEfficientSubtree dungeon

ans10 =
    Node Cavern [Fight (Enemy "Paladin" 50 350)] [
        Node NarrowPassage [Fight (Enemy "Skeleton" 10 15)] [
            Node NarrowPassage [Treasure (Gold 2)] [
                Node UndergroundRiver [Fight (Enemy "Necromancer" 30 100)] [
                    Leaf SlipperyRocks [Fight (Enemy "Skeleton" 10 15)]]]],
        Node SlipperyRocks [Fight (Enemy "Skeleton" 10 15)] [
            Node UndergroundRiver [Fight (Enemy "Goblins" 5 2),Fight (Enemy "Goblins" 5 2)] [
                Leaf NarrowPassage [Fight (Enemy "Lich" 25 50)],
                Leaf Cavern [Fight (Enemy "Goblins" 5 2)],
                Leaf NarrowPassage [Fight (Enemy "Zombie" 15 10)]]],
        Node NarrowPassage [Fight (Enemy "Alchemist" 10 40)] [
            Node UndergroundRiver [Fight (Enemy "Lion" 8 25)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Zombie" 15 10)],
                    Leaf Cavern [Fight (Enemy "Skeleton" 10 15)],
                    Leaf UndergroundRiver [Fight (Enemy "Fighter" 40 100)]]]]]

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(st10, ans10)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (st10, ans10))
