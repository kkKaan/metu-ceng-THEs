import PE2

dungeonMap =
    Node UndergroundRiver [Fight (Enemy "Imp" 4 4)] [
        Node SlipperyRocks [Fight (Enemy "Goblins" 5 2), Treasure (Potion 10)] [
            Leaf NarrowPassage [Fight (Enemy "Skeleton" 10 15)],
            Node Cavern [Fight (Enemy "Necromancer" 60 100)] [
                Leaf NarrowPassage [Treasure (Gold 30), Treasure (Gold 20), Treasure (Potion 5)]],
            Leaf Cavern [Fight (Enemy "Zombie" 15 10)]],
        Node SlipperyRocks [Fight (Enemy "Bear" 15 9)] [
            Node Cavern [Treasure (Gold 10), Treasure (Potion 10)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Goblins" 5 2), Treasure (Potion 5)],
                    Leaf UndergroundRiver [Treasure (Gold 5)],
                    Leaf SlipperyRocks [Fight (Enemy "Imp" 4 4), Fight (Enemy "Imp" 4 4), Fight (Enemy "Imp" 4 4)]],
                Node NarrowPassage [Fight (Enemy "Goblins" 5 2)] [
                    Leaf NarrowPassage [Treasure (Gold 20)]]]]]

gain11 = findMaximumGain 45 dungeonMap

ans11 = 78

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(gain11, ans11)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (gain11, ans11))
