import PE2

dungeonMap = Leaf NarrowPassage []

path5 = traversePath 20 dungeonMap []

ans5 = (20, 0)

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(path5, ans5)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (path5, ans5))
