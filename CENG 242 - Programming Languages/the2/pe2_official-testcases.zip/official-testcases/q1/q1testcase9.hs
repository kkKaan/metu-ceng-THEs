import PE2

dungeonMap =
    Node UndergroundRiver [Fight (Enemy "Imp" 4 4)] [
        Node SlipperyRocks [Fight (Enemy "Goblins" 5 2), Treasure (Potion 10)] [
            Leaf NarrowPassage [Fight (Enemy "Skeleton" 10 15)],
            Node Cavern [Fight (Enemy "Necromancer" 30 100)] [
                Leaf NarrowPassage [Treasure (Gold 30), Treasure (Gold 20), Treasure (Potion 5)]],
            Leaf Cavern [Fight (Enemy "Zombie" 15 10)]],
        Node SlipperyRocks [Fight (Enemy "Bear" 15 9)] [
            Node Cavern [Treasure (Gold 10), Treasure (Potion 10)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Goblins" 5 2), Treasure (Potion 5)],
                    Leaf UndergroundRiver [Treasure (Gold 5)],
                    Leaf SlipperyRocks [Fight (Enemy "Imp" 4 4), Fight (Enemy "Imp" 4 4), Fight (Enemy "Imp" 4 4)]],
                Node NarrowPassage [Fight (Enemy "Goblins" 5 2)] [
                    Leaf NarrowPassage [Treasure (Gold 20)]]]]]

path9 = traversePath 30 dungeonMap [1, 0, 0, 2]

ans9 = (-16, 85)

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(path9, ans9)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (path9, ans9))
