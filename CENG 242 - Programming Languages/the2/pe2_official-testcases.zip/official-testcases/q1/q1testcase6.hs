import PE2

dungeonMap = Leaf NarrowPassage [Treasure (Gold 15), Treasure (Potion 25), Fight (Enemy "Orc" 10 5)]

path6 = traversePath 10 dungeonMap []

ans6 = (25, 20)

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(path6, ans6)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (path6, ans6))
