import PE2

dungeonMap2 = Leaf Cavern [Fight (Enemy "Zombie" 5 10)]

pair2 = mostDistantPair 20 dungeonMap2

ans2 = (0, Leaf Cavern [Fight (Enemy "Zombie" 5 10)])

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(pair2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (pair2, ans2))
