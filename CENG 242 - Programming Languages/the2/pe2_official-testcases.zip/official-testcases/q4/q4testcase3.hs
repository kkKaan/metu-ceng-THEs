import PE2

dungeonMap3 = Node NarrowPassage [Treasure (Gold 10)] [
    Node UndergroundRiver [Fight (Enemy "Orc" 10 5)] [
        Leaf SlipperyRocks [Fight (Enemy "Necromancer" 30 100)]],
    Node Cavern [Fight (Enemy "Goblins" 5 2)] [
        Leaf UndergroundRiver [Fight (Enemy "Lich" 25 50)]]]

pair3 = mostDistantPair 15 dungeonMap3

ans3 = (2, Node NarrowPassage [Treasure (Gold 10)] [
                Leaf UndergroundRiver [Fight (Enemy "Orc" 10 5)],
                Leaf Cavern [Fight (Enemy "Goblins" 5 2)]])

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(pair3, ans3)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (pair3, ans3))
