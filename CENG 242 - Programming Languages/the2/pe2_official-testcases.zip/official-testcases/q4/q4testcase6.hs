import PE2

dungeon = 
    Node Cavern [Fight (Enemy "Goblins" 5 2)] [
        Leaf UndergroundRiver [],
        Node NarrowPassage [Fight (Enemy "Skeleton" 10 15)] [
            Node NarrowPassage [Treasure (Gold 2)] [
                Node UndergroundRiver [Fight (Enemy "Necromancer" 30 100)] [
                    Leaf SlipperyRocks [Fight (Enemy "Skeleton" 10 15)]]]],
        Node SlipperyRocks [Fight (Enemy "Skeleton" 10 15), Treasure (Gold 10), Treasure (Potion 15)] [
            Node UndergroundRiver [Fight (Enemy "Goblins" 5 2), Fight (Enemy "Goblins" 5 2)] [
                Leaf NarrowPassage [Fight (Enemy "Lich" 25 50)],
                Leaf Cavern [Fight (Enemy "Goblins" 5 2)],
                Leaf NarrowPassage [Fight (Enemy "Zombie" 15 10)]]],
        Node NarrowPassage [Fight (Enemy "Bandit" 7 5)] [
            Node UndergroundRiver [Fight (Enemy "Rat" 2 1)] [
                Node Cavern [Fight (Enemy "Lich" 25 50)] [
                    Leaf SlipperyRocks [Fight (Enemy "Zombie" 15 10)],
                    Leaf Cavern [Fight (Enemy "Skeleton" 10 15)],
                    Leaf UndergroundRiver [Fight (Enemy "Necromancer" 30 100)]]]]]

pair6 = mostDistantPair 4 dungeon

ans6 = (0, EmptyTree :: Dungeon)

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(pair6, ans6)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (pair6, ans6))
