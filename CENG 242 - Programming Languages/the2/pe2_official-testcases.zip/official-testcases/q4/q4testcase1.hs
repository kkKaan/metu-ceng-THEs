import PE2

dungeonMap = EmptyTree

pair1 = mostDistantPair 20 dungeonMap

ans1 = (0, EmptyTree :: Dungeon)

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(pair1, ans1)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (pair1, ans1))
