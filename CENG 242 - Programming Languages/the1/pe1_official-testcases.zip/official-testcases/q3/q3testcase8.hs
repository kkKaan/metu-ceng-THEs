import PE3

import Data.List (sort)

diffTerm = map show (derivative [Exp 3 (Power 2) (Exponential (Polynomial [(12, Power 9), (21, Power 7), (4, Power 6), (5, Power 4), (2, Power 2)])), Trig 2 (Power 2) (Sin (Polynomial [(1, Power 5), (3, Power 3), (7, Power 1)])), Trig 1 (Power 0) (Cos (Polynomial [(3, Power 6), (8, Power 4), (1, Power 2)])), Pw 4 (Power 7), Pw 2 (Power 6), Pw 3 (Power 5), Pw 2 (Power 3), Pw 1 (Power 1)])

ans = ["1","6x^2","15x^4","12x^5","28x^6","-2xsin(3x^6 + 8x^4 + x^2)","-32x^3sin(3x^6 + 8x^4 + x^2)","-18x^5sin(3x^6 + 8x^4 + x^2)","14x^2cos(x^5 + 3x^3 + 7x)","18x^4cos(x^5 + 3x^3 + 7x)","10x^6cos(x^5 + 3x^3 + 7x)","4xsin(x^5 + 3x^3 + 7x)","12x^3e^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)","60x^5e^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)","72x^7e^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)","441x^8e^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)","324x^10e^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)","6xe^(12x^9 + 21x^7 + 4x^6 + 5x^4 + 2x^2)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2.5 else 0) results)

main = do
    putStrLn (show points ++ "/2.5")
    putStrLn (check (diffTerm, ans))
