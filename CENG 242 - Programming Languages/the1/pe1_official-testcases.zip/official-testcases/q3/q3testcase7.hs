import PE3

import Data.List (sort)

diffTerm = map show (derivative [Trig 2 (Power 1) (Sin (Polynomial [(1, Power 3), (1, Power 1), (4, Power 0)])), Trig 1 (Power 3) (Cos (Polynomial [(1, Power 5), (3, Power 3), (12, Power 1)]))])

ans = ["-12x^3sin(x^5 + 3x^3 + 12x)","-9x^5sin(x^5 + 3x^3 + 12x)","-5x^7sin(x^5 + 3x^3 + 12x)","3x^2cos(x^5 + 3x^3 + 12x)","2xcos(x^3 + x + 4)","6x^3cos(x^3 + x + 4)","2sin(x^3 + x + 4)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (diffTerm, ans))
