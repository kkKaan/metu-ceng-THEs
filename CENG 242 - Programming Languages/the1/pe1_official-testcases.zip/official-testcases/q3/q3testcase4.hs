import PE3

import Data.List (sort)

diffTerm = function [Trig 2 (Power 0) (Sin (Polynomial [(1, Power 0)])), Const 2, Exp 3 (Power 2) (Exponential (Polynomial [(1, Power 3), (3, Power 2) ,(5, Power 1)])), Pw 3 (Power 3), Pw 5 (Power 5)] 1

ans = 24320.92

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x
doubleCheck (x, y) = if y-0.02 <= x && x <= y+0.02 then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
doubleResults = map doubleCheck pairs
points = sum (map (\x -> if fst x == "Success!" || snd x == "Success!" then 2.5 else 0) (zip results doubleResults))

main = do
    putStrLn (show points ++ "/2.5")
    putStrLn (if check (diffTerm, ans) == "Success!" || doubleCheck (diffTerm, ans) == "Success!" then "Success!" else (if check (diffTerm, ans) == "Success!" then doubleCheck (diffTerm, ans) else check (diffTerm, ans)))
