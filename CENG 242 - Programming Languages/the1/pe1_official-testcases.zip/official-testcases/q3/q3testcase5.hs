import PE3

import Data.List (sort)

diffTerm = map show (derivative [Pw 3 (Power 2), Pw 1 (Power 1)])

ans = ["1","6x"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (diffTerm, ans))
