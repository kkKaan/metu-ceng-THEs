import PE3

import Data.List (sort)

diffTerm = function [Pw 2 (Power 3), Pw 4 (Power 2), Pw 5 (Power 0)] 7

ans = 887.0

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x
doubleCheck (x, y) = if y-0.02 <= x && x <= y+0.02 then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
doubleResults = map doubleCheck pairs
points = sum (map (\x -> if fst x == "Success!" || snd x == "Success!" then 2 else 0) (zip results doubleResults))

main = do
    putStrLn (show points ++ "/2")
    putStrLn (if check (diffTerm, ans) == "Success!" || doubleCheck (diffTerm, ans) == "Success!" then "Success!" else (if check (diffTerm, ans) == "Success!" then doubleCheck (diffTerm, ans) else check (diffTerm, ans)))
