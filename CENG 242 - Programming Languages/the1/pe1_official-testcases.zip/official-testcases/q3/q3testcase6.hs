import PE3

import Data.List (sort)

diffTerm = map show (derivative [Exp 2 (Power 2) (Exponential (Polynomial [(2, Power 3), (3, Power 2)])), Exp 1 (Power 4) (Exponential (Polynomial [(1, Power 2), (1, Power 0)]))])

ans = ["2x^5e^(x^2 + 1)","4x^3e^(x^2 + 1)","12x^3e^(2x^3 + 3x^2)","12x^4e^(2x^3 + 3x^2)","4xe^(2x^3 + 3x^2)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (diffTerm, ans))
