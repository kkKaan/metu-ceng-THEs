import PE3

import Data.List (sort)

diffExp = map show (derivative (Exponential (Polynomial [(3, Power 3)])))

ans = ["9x^2e^(3x^3)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffExp, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (diffExp, ans))
