import PE3

evalExpp = function (Exponential (Polynomial [(3, Power 3)])) 1

ans = 20.09

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x
doubleCheck (x, y) = if y-0.02 <= x && x <= y+0.02 then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(evalExpp, ans)]
results = map check pairs
doubleResults = map doubleCheck pairs
points = sum (map (\x -> if fst x == "Success!" || snd x == "Success!" then 1 else 0) (zip results doubleResults))

main = do
    putStrLn (show points ++ "/1")
    putStrLn (if check (evalExpp, ans) == "Success!" || doubleCheck (evalExpp, ans) == "Success!" then "Success!" else (if check (evalExpp, ans) == "Success!" then doubleCheck (evalExpp, ans) else check (evalExpp, ans)))
