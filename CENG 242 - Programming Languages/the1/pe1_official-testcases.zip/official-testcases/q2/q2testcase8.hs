import PE3

evalTrigg = function (Sin (Polynomial [(1, Power 1), (2, Power 0)])) 5

ans = 0.66

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x
doubleCheck (x, y) = if y-0.02 <= x && x <= y+0.02 then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(evalTrigg, ans)]
results = map check pairs
doubleResults = map doubleCheck pairs
points = sum (map (\x -> if fst x == "Success!" || snd x == "Success!" then 3 else 0) (zip results doubleResults))

main = do
    putStrLn (show points ++ "/3")
    putStrLn (if check (evalTrigg, ans) == "Success!" || doubleCheck (evalTrigg, ans) == "Success!" then "Success!" else (if check (evalTrigg, ans) == "Success!" then doubleCheck (evalTrigg, ans) else check (evalTrigg, ans)))
