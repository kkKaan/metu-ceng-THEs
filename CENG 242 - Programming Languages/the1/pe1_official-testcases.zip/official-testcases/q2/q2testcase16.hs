import PE3

import Data.List (sort)

diffExp = map show (derivative (Exponential (Polynomial [(2, Power 2), (2, Power 1), (3, Power 0)])))

ans = ["4xe^(2x^2 + 2x + 3)","2e^(2x^2 + 2x + 3)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffExp, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (diffExp, ans))
