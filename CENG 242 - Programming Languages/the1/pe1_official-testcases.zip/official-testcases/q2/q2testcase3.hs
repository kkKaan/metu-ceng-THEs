import PE3

evalPolyn = function (Polynomial [(1, Power 2), (1, Power 0)]) 2

ans = 5.0

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x
doubleCheck (x, y) = if y-0.02 <= x && x <= y+0.02 then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(evalPolyn, ans)]
results = map check pairs
doubleResults = map doubleCheck pairs
points = sum (map (\x -> if fst x == "Success!" || snd x == "Success!" then 1 else 0) (zip results doubleResults))

main = do
    putStrLn (show points ++ "/1")
    putStrLn (if check (evalPolyn, ans) == "Success!" || doubleCheck (evalPolyn, ans) == "Success!" then "Success!" else (if check (evalPolyn, ans) == "Success!" then doubleCheck (evalPolyn, ans) else check (evalPolyn, ans)))
