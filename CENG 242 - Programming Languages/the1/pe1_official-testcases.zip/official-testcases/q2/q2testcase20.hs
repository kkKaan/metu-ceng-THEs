import PE3

import Data.List (sort)

diffTerm = map show (derivative (Trig 7 (Power 2) (Sin (Polynomial [(2, Power 8), (1, Power 6), (4, Power 4), (9, Power 2), (1, Power 1), (3, Power 0)]))))

ans = ["14xsin(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)","112x^9cos(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)","42x^7cos(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)","112x^5cos(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)","126x^3cos(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)","7x^2cos(2x^8 + x^6 + 4x^4 + 9x^2 + x + 3)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (diffTerm, ans))
