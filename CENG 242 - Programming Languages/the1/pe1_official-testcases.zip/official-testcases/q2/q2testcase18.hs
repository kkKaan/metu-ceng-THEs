import PE3

import Data.List (sort)

diffPower = map show (derivative (Sin (Polynomial [(2, Power 5), (5, Power 3), (1, Power 1)])))

ans = ["10x^4cos(2x^5 + 5x^3 + x)","15x^2cos(2x^5 + 5x^3 + x)","cos(2x^5 + 5x^3 + x)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffPower, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (diffPower, ans))
