import PE3

import Data.List (sort)

diffTrig = map show (derivative (Cos (Polynomial [(3, Power 3), (4, Power 2), (5, Power 1), (2, Power 0)])))

ans = ["-9x^2sin(3x^3 + 4x^2 + 5x + 2)","-8xsin(3x^3 + 4x^2 + 5x + 2)","-5sin(3x^3 + 4x^2 + 5x + 2)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTrig, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (diffTrig, ans))
