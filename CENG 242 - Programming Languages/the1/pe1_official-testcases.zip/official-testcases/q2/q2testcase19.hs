import PE3

import Data.List (sort)

diffTerm = map show (derivative (Exp 2 (Power 3) (Exponential (Polynomial [(2, Power 4), (3, Power 2), (1, Power 1), (5, Power 0)]))))

ans = ["6x^2e^(2x^4 + 3x^2 + x + 5)","16x^6e^(2x^4 + 3x^2 + x + 5)","12x^4e^(2x^4 + 3x^2 + x + 5)","2x^3e^(2x^4 + 3x^2 + x + 5)"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffTerm, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 4 else 0) results)

main = do
    putStrLn (show points ++ "/4")
    putStrLn (check (diffTerm, ans))
