import PE3

import Data.List (sort)

diffPoly = map show (derivative (Polynomial [(1, Power 3), (3, Power 2), (3, Power 1), (1, Power 0)]))

ans = ["3x^2","6x","3"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffPoly, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (diffPoly, ans))
