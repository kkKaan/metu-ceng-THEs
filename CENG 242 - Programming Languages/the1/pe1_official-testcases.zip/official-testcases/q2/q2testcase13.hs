import PE3

import Data.List (sort)

diffPoly = map show (derivative (Polynomial [(3, Power 3), (4, Power 2), (1, Power 0)]))

ans = ["9x^2","8x"]

check (x, y) = if sort x == sort y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(diffPoly, ans)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (diffPoly, ans))
