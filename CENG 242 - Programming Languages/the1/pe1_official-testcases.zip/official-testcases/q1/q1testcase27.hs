import PE3

eq2 = Power 3 == Power 7

ans2 = False

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(eq2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 2 else 0) results)

main = do
    putStrLn (show points ++ "/2")
    putStrLn (check (eq2, ans2))
