import PE3

showPoly2 = show (Polynomial [(4, Power 1), (5, Power 0)])

ans2 = "4x + 5"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showPoly2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showPoly2, ans2))
