import PE3

showPoly5 = show (Polynomial [(-1, Power 6), (-15, Power 5), (85, Power 4), (-225, Power 3), (274, Power 2), (-120, Power 1)])

ans5 = "-x^6 + -15x^5 + 85x^4 + -225x^3 + 274x^2 + -120x"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showPoly5, ans5)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showPoly5, ans5))
