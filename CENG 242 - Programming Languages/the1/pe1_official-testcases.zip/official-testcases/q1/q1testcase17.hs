import PE3

showTrig2 = show (Sin (Polynomial [(1, Power 1)]))

ans2 = "sinx"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showTrig2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showTrig2, ans2))
