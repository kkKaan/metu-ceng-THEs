import PE3

showPoly3 = show (Polynomial [(3, Power 2), (2, Power 0)])

ans3 = "3x^2 + 2"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showPoly3, ans3)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showPoly3, ans3))
