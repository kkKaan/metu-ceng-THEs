import PE3

showExp4 = show (Exponential (Polynomial [(4, Power 3), (3, Power 1), (5, Power 0)]))

ans4 = "e^(4x^3 + 3x + 5)"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showExp4, ans4)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showExp4, ans4))
