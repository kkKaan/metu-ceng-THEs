import PE3

showTrig5 = show (Cos (Polynomial [(3, Power 3), (1, Power 1), (12, Power 0)]))

ans5 = "cos(3x^3 + x + 12)"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showTrig5, ans5)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showTrig5, ans5))
