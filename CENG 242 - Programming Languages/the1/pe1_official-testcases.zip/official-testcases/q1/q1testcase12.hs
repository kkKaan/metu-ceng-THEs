import PE3

showExp2 = show (Exponential (Polynomial [(3, Power 1)]))

ans2 = "e^3x"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showExp2, ans2)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showExp2, ans2))
