import PE3

showExp3 = show (Exponential (Polynomial [(3, Power 3), (4, Power 1)]))

ans3 = "e^(3x^3 + 4x)"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showExp3, ans3)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showExp3, ans3))
