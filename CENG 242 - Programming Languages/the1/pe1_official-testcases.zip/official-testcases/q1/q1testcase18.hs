import PE3

showTrig3 = show (Sin (Polynomial [(-1, Power 1)]))

ans3 = "sin(-x)"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showTrig3, ans3)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showTrig3, ans3))
