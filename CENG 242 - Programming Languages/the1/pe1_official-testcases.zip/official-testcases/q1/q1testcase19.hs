import PE3

showTrig4 = show (Cos (Polynomial [(-6, Power 1), (2, Power 0)]))

ans4 = "cos(-6x + 2)"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showTrig4, ans4)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showTrig4, ans4))
