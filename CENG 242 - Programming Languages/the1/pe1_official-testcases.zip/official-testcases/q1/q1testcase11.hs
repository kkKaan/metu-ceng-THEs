import PE3

showExp1 = show (Exponential (Polynomial [(5, Power 0)]))

ans1 = "e^5"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showExp1, ans1)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showExp1, ans1))
