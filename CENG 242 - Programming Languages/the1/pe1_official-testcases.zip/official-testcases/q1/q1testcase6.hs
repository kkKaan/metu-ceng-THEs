import PE3

showPoly1 = show (Polynomial [(42, Power 0)])

ans1 = "42"

check (x, y) = if x == y then "Success!" else "Fail\nExpected:\n" ++ show y ++ "\n" ++ "Result:\n" ++ show x

pairs = [(showPoly1, ans1)]
results = map check pairs
points = sum (map (\x -> if x == "Success!" then 1 else 0) results)

main = do
    putStrLn (show points ++ "/1")
    putStrLn (check (showPoly1, ans1))
